const images = {
src: require('~/assets/images/Tiktok.svg').default
}
export default images