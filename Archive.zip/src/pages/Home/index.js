function Home() {
    return ( <h2>Home page F8!!!!!</h2> );
}

export default Home;