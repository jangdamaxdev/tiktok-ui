function Profile() {
  return <h2>Profile page</h2>
}

export default Profile
