function Following() {
    return ( <h2>Following page</h2> );
}

export default Following;